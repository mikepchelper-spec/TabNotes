chrome.runtime.onInstalled.addListener(()=>{console.log("TabNotes installed")});chrome.action.onClicked.addListener(e=>{e.id&&chrome.action.openPopup()});
